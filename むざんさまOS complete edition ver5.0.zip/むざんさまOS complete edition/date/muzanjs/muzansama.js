//addEventListenerを簡略化（body部分)
function bodyEvent (eventname,eventcontent) {
    document.body.addEventListener(eventname,eventcontent);
}
//addEventListenerを簡略化
function addEvent (subject,eventname,eventcontent) {
    subject.addEventListener(eventname,eventcontent);
}
//getElementById("");を簡略化
var tagID;
var getID = function (documentID) {
    tagID = document.getElementById(documentID);
}
//情報
var info = {
    programname: "muzansama.js",
    version: "2.0",
    build: "2027",
    info: "読み込み完了！"
}
//読み込まれたらconsolelogに情報を表示させる
console.info(info);